export type Proizvođač = {
    idProizvodac: number,
    nazivProizvodac: string;
    godOsnutka: string;
  }