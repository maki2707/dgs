export type MinHardver = {
    idMinhardver: number;
    procesor: string;
    grafickaKartica: string;
    ram: string;
    disk: string;
  }