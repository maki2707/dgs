export type Admin = {
    idKorisnik: number;
    emailAdresa: string;
    korisnickoIme: string;
    idUloga: number;
    idProizvodac: number | null;
  };