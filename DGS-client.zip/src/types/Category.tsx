export type Kategorija = {
    nazivKategorije: string;
    opisKategorije: string;
    nazivAdmin: string,
    idAdmin: number,
    idKategorija: number
  }