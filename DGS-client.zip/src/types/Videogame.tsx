export type Videoigra = {
    idProizvodac: number,
    nazivProizvodac: string,
    idMinHardver: number,
    minHardver: string,
    nazivVideoigre: string,
    idVideoigra: number,
    cijenaVideoigre: number,
  }